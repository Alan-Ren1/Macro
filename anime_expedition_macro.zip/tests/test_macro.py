import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import anime_expedition_macro as macro


class MacroConfigTests(unittest.TestCase):
    def test_load_config_merges_defaults(self):
        config = macro.load_config(os.path.join(os.path.dirname(__file__), "..", "config.json"))
        self.assertIn("story", config["modes"])
        self.assertIn("pvp", config["modes"])

    def test_list_modes_returns_sorted_names(self):
        config = macro.load_config(os.path.join(os.path.dirname(__file__), "..", "config.json"))
        self.assertEqual(list(macro.list_modes(config)), ["pvp", "story"])

    def test_get_steps_supports_enter_and_leave_sections(self):
        config = {
            "modes": {
                "story": {
                    "enter": [{"action": "wait", "seconds": 1.0}],
                    "leave": [{"action": "press", "key": "esc"}],
                }
            }
        }
        self.assertEqual(macro.get_steps(config, "story", "enter")[0]["action"], "wait")
        self.assertEqual(macro.get_steps(config, "story", "leave")[0]["action"], "press")


if __name__ == "__main__":
    unittest.main()
