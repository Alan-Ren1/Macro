#!/usr/bin/env python3
import argparse
import json
import os
import sys
import time
from typing import Any, Dict, List, Optional


DEFAULT_CONFIG: Dict[str, Any] = {
    "hotkey": "f6",
    "click_delay": 0.25,
    "queue_wait_seconds": 5.0,
    "repeat": 1,
    "modes": {
        "story": [
            {"action": "wait", "seconds": 1.0},
            {"action": "click", "x": 0, "y": 0},
            {"action": "wait", "seconds": 1.0},
            {"action": "click", "x": 0, "y": 0},
            {"action": "wait", "seconds": 5.0},
            {"action": "click", "x": 0, "y": 0},
        ],
        "pvp": [
            {"action": "wait", "seconds": 1.0},
            {"action": "click", "x": 0, "y": 0},
            {"action": "wait", "seconds": 1.0},
            {"action": "click", "x": 0, "y": 0},
            {"action": "wait", "seconds": 5.0},
            {"action": "click", "x": 0, "y": 0},
        ],
    },
}


class MacroError(RuntimeError):
    """Raised when the macro cannot be executed."""


def load_config(path: Optional[str] = None) -> Dict[str, Any]:
    config_path = path or os.path.join(os.path.dirname(__file__), "config.json")
    if not os.path.exists(config_path):
        return json.loads(json.dumps(DEFAULT_CONFIG))

    with open(config_path, "r", encoding="utf-8") as handle:
        user_data = json.load(handle)

    merged = json.loads(json.dumps(DEFAULT_CONFIG))
    merged.update(user_data)
    if "modes" in user_data:
        merged["modes"] = {**merged["modes"], **user_data["modes"]}
    return merged


def list_modes(config: Dict[str, Any]) -> List[str]:
    return sorted(config.get("modes", {}).keys())


def get_steps(config: Dict[str, Any], mode: str, section: str) -> List[Dict[str, Any]]:
    mode_config = config.get("modes", {}).get(mode, {})
    if isinstance(mode_config, dict):
        if section in mode_config:
            steps = mode_config[section]
            if isinstance(steps, list):
                return steps
        if "steps" in mode_config:
            return mode_config["steps"]
        if "enter" in mode_config and section == "enter":
            return mode_config["enter"]
        if "leave" in mode_config and section == "leave":
            return mode_config["leave"]
        if "default" in mode_config:
            return mode_config["default"]
    if isinstance(mode_config, list):
        return mode_config
    return []


def resolve_mode(config: Dict[str, Any], mode: Optional[str]) -> str:
    modes = list_modes(config)
    if not modes:
        raise MacroError("No modes were configured.")
    if mode is None:
        raise MacroError(f"Choose one of: {', '.join(modes)}")
    if mode not in modes:
        raise MacroError(f"Unknown mode '{mode}'. Choose one of: {', '.join(modes)}")
    return mode


def run_sequence(config: Dict[str, Any], mode: str, repeats: int = 1, dry_run: bool = False, section: str = "default") -> None:
    try:
        import pyautogui  # type: ignore
    except ImportError as exc:
        raise MacroError("Install dependencies first: pip install -r requirements.txt") from exc

    steps = get_steps(config, mode, section)
    if not steps:
        raise MacroError(f"No steps found for mode '{mode}' in section '{section}'.")

    if dry_run:
        print(f"Dry run for mode '{mode}' section '{section}' with {repeats} cycle(s):")
        for index, step in enumerate(steps, 1):
            print(f"  {index}. {step}")
        return

    for cycle in range(1, repeats + 1):
        print(f"Starting cycle {cycle}/{repeats} for mode '{mode}' section '{section}'.")
        for step in steps:
            action = step.get("action")
            if action == "wait":
                seconds = float(step.get("seconds", 0.0))
                time.sleep(seconds)
            elif action == "click":
                x = int(step.get("x", 0))
                y = int(step.get("y", 0))
                pyautogui.moveTo(x, y, duration=0.2)
                pyautogui.click()
                time.sleep(float(config.get("click_delay", 0.25)))
            elif action == "press":
                key = str(step.get("key", ""))
                pyautogui.press(key)
            else:
                raise MacroError(f"Unsupported action '{action}'.")
        time.sleep(float(config.get("queue_wait_seconds", 0.0)))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Anime Expedition macro runner")
    parser.add_argument("--config", default=None, help="Path to your JSON config file")
    parser.add_argument("--mode", default=None, help="Mode to run (must exist in the config)")
    parser.add_argument("--list-modes", action="store_true", help="Show the configured modes")
    parser.add_argument("--repeat", type=int, default=1, help="How many times to run the sequence")
    parser.add_argument("--dry-run", action="store_true", help="Print the sequence without clicking")
    parser.add_argument("--enter", action="store_true", help="Run the enter sequence for the selected mode")
    parser.add_argument("--leave", action="store_true", help="Run the leave sequence for the selected mode")
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    config = load_config(args.config)
    if args.list_modes:
        print("Configured modes:")
        for mode in list_modes(config):
            print(f"- {mode}")
        return 0

    mode = resolve_mode(config, args.mode)
    if args.leave:
        run_sequence(config, mode, repeats=max(1, args.repeat), dry_run=args.dry_run, section="leave")
    elif args.enter:
        run_sequence(config, mode, repeats=max(1, args.repeat), dry_run=args.dry_run, section="enter")
    else:
        run_sequence(config, mode, repeats=max(1, args.repeat), dry_run=args.dry_run, section="default")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except MacroError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        raise SystemExit(1)
